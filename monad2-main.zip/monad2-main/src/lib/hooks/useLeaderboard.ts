import { useCallback } from "react";
import { getLeaderboard } from "~/lib/backend";
import { decimalToPlainString } from "./useDecimal";

/**
 * Hook to fetch leaderboard data and send it to Unity GameManager.
 * @param sendMessage - Unity sendMessage function.
 */
export function useLeaderboard(
  sendMessage: (
    gameObject: string,
    methodName: string,
    parameter: string
  ) => void
) {
  const updateLeaderboard = useCallback(() => {
    (async () => {
      const data = await getLeaderboard();
      const normalize = (val: string) => Number(val).toFixed(2);
      const topUsers = data.top_users.map(
        (u: { name: string; balance: string }) => ({
          ...u,
          balance: normalize(u.balance),
        })
      );
      sendMessage("GameManager", "UpdateTopUsers", JSON.stringify(topUsers));
      sendMessage("GameManager", "UpdateMyInfo", JSON.stringify(data.me));
    })();
  }, [sendMessage]);

  return updateLeaderboard;
}
