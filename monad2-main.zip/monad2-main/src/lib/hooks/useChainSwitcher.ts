import { useCallback, useEffect } from "react";
import { useSwitchChain, useChainId } from "wagmi";
import { monadTestnet } from "wagmi/chains";

/**
 * Hook to automatically switch the connected chain to monadTestnet.
 */
export function useChainSwitcher() {
  const { switchChain } = useSwitchChain();
  const chainId = useChainId();

  const handleSwitchChain = useCallback(() => {
    switchChain({ chainId: monadTestnet.id });
  }, [switchChain]);

  useEffect(() => {
    handleSwitchChain();
  }, [chainId, handleSwitchChain]);

  return { switchChain, handleSwitchChain };
}
