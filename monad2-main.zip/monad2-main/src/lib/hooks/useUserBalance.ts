import { useCallback } from "react";
import { getUser } from "~/lib/backend";
import { decimalToPlainString } from "./useDecimal";
import { useAccount, useBalance, useClient, usePublicClient } from "wagmi";
import { getBalance } from "viem/actions";
import { formatEther, parseEther } from "viem";

/**
 * Hook to fetch user balance and send it to Unity GameManager.
 * @param sendMessage - Unity sendMessage function.
 */
export function useUserBalance(
  sendMessage: (
    gameObject: string,
    methodName: string,
    parameter: string
  ) => void
) {
  const { address, isConnected, chainId } = useAccount();
  const publicClient = usePublicClient({
    chainId: chainId,
  });

  const updateUserBalance = useCallback(() => {
    (async () => {
      if (!isConnected || !address) {
        console.error("User not connected or address not available");
        return;
      }
      const balance = await publicClient?.getBalance({
        address,
      });
      const balanceStr = formatEther(balance ?? 0n);
      sendMessage("GameManager", "UpdateBalanceTextJS", balanceStr);
    })();
  }, [sendMessage, address, publicClient]);

  return updateUserBalance;
}
