import { useCallback } from "react";
import { completeTutorial } from "~/lib/backend";

/**
 * Hook to mark the tutorial as completed and then update user balance.
 * @param updateUserBalance - Callback to refresh the user's balance.
 */
export function useTutorial(updateUserBalance: () => void) {
  const handleTutorialComplete = useCallback(() => {
    (async () => {
      await completeTutorial();
      updateUserBalance();
    })();
  }, [updateUserBalance]);

  return { handleTutorialComplete };
}
