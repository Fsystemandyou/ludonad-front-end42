import { useCallback, useState, useEffect } from "react";
import sdk, { SignIn as SignInCore } from "@farcaster/frame-sdk";
import { signIn as nextSignIn, getCsrfToken } from "next-auth/react";
import { farcasterAuth } from "~/lib/backend";

/**
 * Hook to handle Farcaster authentication and NextAuth sign-in.
 * @param sendMessage - Unity sendMessage function.
 * @returns signingIn, signInFailure, handleSignIn
 */
export function useFarcasterAuth(
  sendMessage: (
    gameObject: string,
    methodName: string,
    parameter: string
  ) => void
) {
  const [signingIn, setSigningIn] = useState(false);
  const [signInFailure, setSignInFailure] = useState<string | undefined>();

  const getNonce = useCallback(async () => {
    const nonce = await getCsrfToken();
    if (!nonce) throw new Error("Unable to generate nonce");
    return nonce;
  }, []);

  const handleSignIn = useCallback(async () => {
    try {
      console.log("handleSignIn");
      setSigningIn(true);
      setSignInFailure(undefined);
      const nonce = await getNonce();
      const result = await sdk.actions.signIn({ nonce });

      await nextSignIn("credentials", {
        message: result.message,
        signature: result.signature,
        redirect: false,
      });

      const resultUser = await farcasterAuth(result);
      sendMessage(
        "Trump",
        "CheckIfTutorialNeeded",
        resultUser.has_seen_tutorial.toString()
      );
    } catch (e) {
      if (e instanceof SignInCore.RejectedByUser) {
        setSignInFailure("Rejected by user");
      } else {
        setSignInFailure("Unknown error");
      }
    } finally {
      setSigningIn(false);
    }
  }, [getNonce, sendMessage]);

  // automatically sign in once Unity is loaded and authenticated
  const { authenticated, isLoaded } = {} as any; // placeholder, actual auth status passed externally

  return { signingIn, signInFailure, handleSignIn };
}
