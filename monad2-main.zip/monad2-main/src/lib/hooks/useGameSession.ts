import { useCallback, useState } from "react";
import { startGameAPI, finalizeGameAPI } from "~/lib/backend";
import { usePrivyWallet } from "./usePrivyWallet";
import {
  useAccount,
  usePublicClient,
  useSendTransaction,
  useWalletClient,
} from "wagmi";
import frameSdk from "@farcaster/frame-sdk";

/**
 * Hook to manage game session lifecycle with backend APIs.
 * @param sendMessage - Unity sendMessage function.
 * @returns gameSessionId, handleGameStart, handleGameOver
 */
export function useGameSession() {
  const [gameSessionId, setGameSessionId] = useState<number | null>(null);
  const { chainId, address } = useAccount();
  // const { sendTransactionAsync } = useSendTransaction();
  const { sendTransactionAsync } = useSendTransaction();
  const { wallet } = usePrivyWallet();

  const handleGameStart = useCallback(
    (...args: any[]) => {
      (async () => {
        if (!wallet) {
          console.error("Wallet is not connected");
          return;
        }
        const [positionToken, isLong] = args;
        const positionSizeFix = parseFloat(positionToken);
        const trade = isLong === "true";

        await wallet?.switchChain(chainId!);

        const data = await startGameAPI(positionSizeFix, trade);
        setGameSessionId(data.id);
      })();
    },
    [chainId, address, wallet]
  );

  const handleGameOver = useCallback(
    (...args: any[]) => {
      (async () => {
        const [finalLev, pnl, posToken, posFix, risk, rol, startLev] = args;

        if (gameSessionId === null) {
          console.error("Game session ID is null, cannot finalize game");
          return;
        }

        await finalizeGameAPI({
          final_leverage: parseFloat(finalLev),
          id: gameSessionId,
          pnl: parseFloat(pnl),
          position_size_fix: parseFloat(posToken),
          position_size_percent: parseFloat(posFix),
          risk,
          roi: parseFloat(rol),
          start_leverage: parseFloat(startLev),
        });
      })();
    },
    [gameSessionId]
  );

  return { gameSessionId, handleGameStart, handleGameOver };
}
