/**
 * Convert a decimal number or string into a plain string without trailing zeros.
 * @param value - The number or numeric string to format.
 * @returns The formatted decimal string.
 */
export function decimalToPlainString(value: string | number): string {
  const num = Number(value);
  if (isNaN(num)) return "0";
  return num.toFixed(18).replace(/\.?0+$/, "");
}
