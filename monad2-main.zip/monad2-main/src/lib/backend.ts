import { SignInResult } from "@farcaster/frame-core/dist/actions/SignIn";

if (!process.env.NEXT_PUBLIC_BACKEND_URL) {
  throw new Error("BACKEND_URL not configured");
}

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL;

/**
 * Fetch the leaderboard data.
 */
export async function getLeaderboard() {
  const token = localStorage.getItem("token");
  const response = await fetch(`${BACKEND_URL}/leaderboard`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "ngrok-skip-browser-warning": "123",
    },
  });
  if (!response.ok) {
    throw new Error("Failed to fetch leaderboard");
  }
  return response.json();
}

/**
 * Fetch the current user's data.
 */
export async function getUser() {
  const token = localStorage.getItem("token");
  const response = await fetch(`${BACKEND_URL}/user/me`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "ngrok-skip-browser-warning": "123",
    },
  });
  if (!response.ok) {
    throw new Error("Failed to fetch user");
  }
  return response.json();
}

/**
 * Authenticate via Farcaster and store the returned token.
 */
export async function farcasterAuth(farcasterSignInRes: SignInResult) {
  const response = await fetch(`${BACKEND_URL}/auth/farcaster`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "ngrok-skip-browser-warning": "123",
    },
    body: JSON.stringify({
      message: farcasterSignInRes.message,
      signature: farcasterSignInRes.signature,
    }),
  });
  if (!response.ok) {
    throw new Error("Failed to authenticate with Farcaster");
  }
  const token = response.headers.get("New-Access-Token");
  if (token) {
    localStorage.setItem("token", token);
  }
  return response.json();
}

/**
 * Mark the tutorial as completed.
 */
export async function completeTutorial() {
  const token = localStorage.getItem("token");
  const response = await fetch(`${BACKEND_URL}/tutorial/completed`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "ngrok-skip-browser-warning": "123",
    },
  });
  if (!response.ok) {
    throw new Error("Failed to complete tutorial");
  }
}

/**
 * Start a new game session.
 * @param positionSizeFix - Position size for game start.
 * @param trade - Boolean indicating trade direction.
 */
export async function startGameAPI(positionSizeFix: number, trade: boolean) {
  const token = localStorage.getItem("token");
  const response = await fetch(`${BACKEND_URL}/game/start`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "ngrok-skip-browser-warning": "123",
    },
    body: JSON.stringify({ position_size_fix: positionSizeFix, trade }),
  });
  if (!response.ok) {
    throw new Error("Failed to start game");
  }
  return response.json();
}

/**
 * Finalize an existing game session.
 * @param params - Object containing final game parameters.
 */
export async function finalizeGameAPI(params: {
  id: number;
  final_leverage: number;
  pnl: number;
  position_size_fix: number;
  position_size_percent: number;
  risk: string;
  roi: number;
  start_leverage: number;
}) {
  const token = localStorage.getItem("token");
  const response = await fetch(`${BACKEND_URL}/game/final`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "ngrok-skip-browser-warning": "123",
    },
    body: JSON.stringify(params),
  });
  if (!response.ok) {
    throw new Error("Failed to finalize game");
  }
}
