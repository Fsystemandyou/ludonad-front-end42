import React from "react";
import { Unity } from "react-unity-webgl";

/**
 * Component that renders the Unity WebGL build in a responsive container.
 * @param unityProvider - Unity context provider from useUnityContext.
 */
export function UnityContainer({
  unityProvider,
}: {
  unityProvider: ReturnType<typeof Unity> extends React.ElementType
    ? React.ComponentProps<typeof Unity>["unityProvider"]
    : any;
}) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#000",
        width: "100vw",
        height: "100vh",
        padding: "env(safe-area-inset)",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "clamp(320px, 90vw, 520px)",
          aspectRatio: "9 / 16",
          backgroundColor: "#000",
          borderRadius: "12px",
          overflow: "hidden",
          boxShadow: "0 0 16px rgba(0, 0, 0, 0.3)",
        }}
      >
        <Unity
          unityProvider={unityProvider}
          style={{
            width: "100%",
            height: "100%",
            display: "block",
            imageRendering: "crisp-edges",
          }}
        />
      </div>
    </div>
  );
}
