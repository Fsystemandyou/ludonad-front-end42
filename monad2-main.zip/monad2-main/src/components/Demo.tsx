/* eslint-disable */
"use client";

import React, { useEffect } from "react";
import { useUnityContext } from "react-unity-webgl";
import { UnityContainer } from "~/components/UnityContainer";
import { useFrame } from "~/components/providers/FrameProvider";
import { useChainSwitcher } from "~/lib/hooks/useChainSwitcher";
import { useUserBalance } from "~/lib/hooks/useUserBalance";
import { useLeaderboard } from "~/lib/hooks/useLeaderboard";
import { useGameSession } from "~/lib/hooks/useGameSession";
import { useFarcasterAuth } from "~/lib/hooks/useFarcasterAuth";
import { useTutorial } from "~/lib/hooks/useTutorial";
import { usePrivy } from "@privy-io/react-auth";
import { usePrivyWallet } from "~/lib/hooks/usePrivyWallet";

interface DemoProps {
  title?: string;
}

export default function Demo({ title = "Frames v2 Demo" }: DemoProps) {
  const {
    isSDKLoaded,
    context,
    addFrame,
    notificationDetails,
    lastEvent,
    openUrl,
    close,
  } = useFrame();

  const { ready: privyReady, authenticated: privyAuthenticated } = usePrivy();

  const {
    unityProvider,
    isLoaded: isUnityLoaded,
    sendMessage,
    addEventListener,
    removeEventListener,
  } = useUnityContext({
    loaderUrl: "build/monad1.loader.js",
    dataUrl: "build/monad1.data.unityweb",
    frameworkUrl: "build/monad1.framework.js.unityweb",
    codeUrl: "build/monad1.wasm.unityweb",
  });

  const { handleSwitchChain } = useChainSwitcher();
  const updateUserBalance = useUserBalance(sendMessage);
  const updateLeaderboard = useLeaderboard(sendMessage);
  const { gameSessionId, handleGameStart, handleGameOver } = useGameSession();
  const { signingIn, signInFailure, handleSignIn } =
    useFarcasterAuth(sendMessage);
  const { handleTutorialComplete } = useTutorial(updateUserBalance);
  const { wallet } = usePrivyWallet();

  useEffect(() => {
    console.log("isSDKLoaded", isSDKLoaded);
    handleSwitchChain();
    console.log("context", context);
  }, [isSDKLoaded, context, handleSwitchChain]);

  useEffect(() => {
    if (isUnityLoaded && privyReady) {
      handleSignIn();
    }
  }, [isUnityLoaded, privyReady, handleSignIn]);

  useEffect(() => {
    addEventListener("Logout", () => {
      close();
    });
    addEventListener("UpdateBalance", () => {
      console.log("UpdateBalance");
      updateUserBalance();
    });
    addEventListener("LeaderBoard", () => {
      updateLeaderboard();
    });
    addEventListener("CloseTutor", () => {
      handleTutorialComplete();
    });
    addEventListener("GameStart", (...args) => {
      handleGameStart(...args);
    });
    addEventListener("GameOver", (...args) => {
      handleGameOver(...args);
    });
    return () => {
      removeEventListener("Logout", () => {
        close();
      });
      removeEventListener("UpdateBalance", () => {
        updateUserBalance();
      });
      removeEventListener("LeaderBoard", () => {
        updateLeaderboard();
      });
      removeEventListener("CloseTutor", () => {
        handleTutorialComplete();
      });
      removeEventListener("GameStart", (...args) => {
        handleGameStart(...args);
      });
      removeEventListener("GameOver", (...args) => {
        handleGameOver(...args);
      });
    };
  }, [
    addEventListener,
    removeEventListener,
    close,
    updateUserBalance,
    updateLeaderboard,
    handleGameStart,
    handleGameOver,
  ]);

  if (!isSDKLoaded || !privyReady) {
    return <div>Loading...</div>;
  }

  // return <p>Hello!</p>;

  return <UnityContainer unityProvider={unityProvider} />;
}
