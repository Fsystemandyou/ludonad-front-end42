"use client";

import dynamic from "next/dynamic";
import type { Session } from "next-auth";
import { SessionProvider } from "next-auth/react";
import { FrameProvider } from "~/components/providers/FrameProvider";
import { PrivyProvider } from "@privy-io/react-auth";
import { monadTestnet } from "viem/chains";

const WagmiProvider = dynamic(
  () => import("~/components/providers/WagmiProvider"),
  {
    ssr: false,
  }
);

export function Providers({
  session,
  children,
}: {
  session: Session | null;
  children: React.ReactNode;
}) {
  return (
    <SessionProvider session={session}>
      <PrivyProvider
        appId={process.env.NEXT_PUBLIC_PRIVY_APP_ID!}
        config={{
          supportedChains: [monadTestnet],
        }}
        // clientId={process.env.NEXT_PUBLIC_PRIVY_CLIENT_ID!}
      >
        <WagmiProvider>
          <FrameProvider>{children}</FrameProvider>
        </WagmiProvider>
      </PrivyProvider>
    </SessionProvider>
  );
}
